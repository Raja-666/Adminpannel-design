[![@ ](https://img.shields.io/badge/@%20--lightgrey.svg?style=flat-square)](https://github.com//)
[![npm package][npm--badge]][npm-]
[![NPM downloads][npm--download]][npm-]  
[![@ react](https://img.shields.io/badge/@%20-react-lightgrey.svg?style=flat-square)](https://github.com//react)
[![npm package][npm--react-badge]][npm--react]
[![NPM downloads][npm--react-download]][npm--react]  

[npm-]: https://www.npmjs.com/package/@/
[npm--badge]: https://img.shields.io/npm/v/@/.png?style=flat-square
[npm--download]: https://img.shields.io/npm/dm/@/.svg?style=flat-square
[npm--react]: https://www.npmjs.com/package/@/react
[npm--react-badge]: https://img.shields.io/npm/v/@/react.png?style=flat-square
[npm--react-download]: https://img.shields.io/npm/dm/@/react.svg?style=flat-square
[npm]: https://www.npmjs.com/package/@/react

#  Free React Admin Template

 is meant to be the UX game changer. Pure & transparent code is devoid of redundant components, so the app is light enough to offer ultimate user experience. This means mobile devices also, where the navigation is just as easy and intuitive as on a desktop or laptop. The  Layout API lets you customize your project for almost any device – be it Mobile, Web or WebApp –  covers them all!

## Table of Contents

* [Versions](#versions)
* [ Pro](#-pro)
* [Quick Start](#quick-start)
* [Installation](#installation)
* [Basic usage](#basic-usage)
* [What's included](#whats-included)
* [Documentation](#documentation)
* [Versioning](#versioning)
* [Creators](#creators)
* [Community](#community)
* [Support  Development](#support--development)
* [Copyright and License](#copyright-and-license)

## Versions

* [ Free Bootstrap Admin Template](https://github.com//-free-bootstrap-admin-template)
* [ Free Angular Admin Template](https://github.com//-free-angular-admin-template)
* [ Free React.js Admin Template](https://github.com//-free-react-admin-template)
* [ Free Vue.js Admin Template](https://github.com//-free-vue-admin-template)

##  Pro

* 💪  [ Pro Angular Admin Template](https://.io/product/angular-dashboard-template/)
* 💪  [ Pro Bootstrap Admin Template](https://.io/product/bootstrap-dashboard-template/)
* 💪  [ Pro React Admin Template](https://.io/product/react-dashboard-template/)
* 💪  [ Pro Vue Admin Template](https://.io/product/vue-dashboard-template/)

## Quick Start

- [Download the latest release](https://github.com//-free-react-admin-template/archive/refs/heads/main.zip)
- Clone the repo: `git clone https://github.com//-free-react-admin-template.git`

### Installation

``` bash
$ npm install
```

or

``` bash
$ yarn install
```

### Basic usage

``` bash
# dev server with hot reload at http://localhost:3000
$ npm start 
```

or 

``` bash
# dev server with hot reload at http://localhost:3000
$ yarn start
```

Navigate to [http://localhost:3000](http://localhost:3000). The app will automatically reload if you change any of the source files.

#### Build

Run `build` to build the project. The build artifacts will be stored in the `build/` directory.

```bash
# build for production with minification
$ npm run build
```

or

```bash
# build for production with minification
$ yarn build
```

## What's included

Within the download you'll find the following directories and files, logically grouping common assets and providing both compiled and minified variations. You'll see something like this:

```
-free-react-admin-template
├── public/          # static files
│   └── index.html   # html template
│
├── src/             # project root
│   ├── assets/      # images, icons, etc.
│   ├── components/  # common components - header, footer, sidebar, etc.
│   ├── layouts/     # layout containers
│   ├── scss/        # scss styles
│   ├── views/       # application views
│   ├── _nav.js      # sidebar navigation config
│   ├── App.js
│   ├── ...
│   ├── index.js
│   ├── routes.js    # routes config
│   └── store.js     # template state example 
│
└── package.json
```

## Documentation

The documentation for the  Admin Template is hosted at our website [ for React](https://.io/react/)

## Versioning

For transparency into our release cycle and in striving to maintain backward compatibility,  Free Admin Template is maintained under [the Semantic Versioning guidelines](http://semver.org/).

See [the Releases section of our project](https://github.com//-free-react-admin-template/releases) for changelogs for each release version.

## Creators

**Łukasz Holeczek**
* <https://twitter.com/lukaszholeczek>
* <https://github.com/mrholek>
* <https://github.com/>

** team**
* https://github.com/orgs//people

## Community

Get updates on 's development and chat with the project maintainers and community members.

- Follow [@core_ui on Twitter](https://twitter.com/core_ui).
- Read and subscribe to [ Blog](https://.ui/blog/).

## Support  Development

 is an MIT-licensed open source project and is completely free to use. However, the amount of effort needed to maintain and develop new features for the project is not sustainable without proper financial backing. You can support development by buying the [ PRO](https://.io/pricing/) or by becoming a sponsor via [Open Collective](https://opencollective.com//).

<!--- StartOpenCollectiveBackers -->

### Platinum Sponsors

Support this project by [becoming a Platinum Sponsor](https://opencollective.com//contribute/platinum-sponsor-40959/). A large company logo will be added here with a link to your website.

<a href="https://opencollective.com//contribute/platinum-sponsor-40959/checkout"><img src="https://opencollective.com//tiers/platinum-sponsor/0/avatar.svg?avatarHeight=100"></a>

### Gold Sponsors

Support this project by [becoming a Gold Sponsor](https://opencollective.com//contribute/gold-sponsor-40960/). A big company logo will be added here with a link to your website.

<a href="https://opencollective.com//contribute/gold-sponsor-40960/checkout"><img src="https://opencollective.com//tiers/gold-sponsor/0/avatar.svg?avatarHeight=100"></a> 

### Silver Sponsors

Support this project by [becoming a Silver Sponsor](https://opencollective.com//contribute/silver-sponsor-40967/). A medium company logo will be added here with a link to your website.

<a href="https://opencollective.com//contribute/silver-sponsor-40967/checkout"><img src="https://opencollective.com//tiers/gold-sponsor/0/avatar.svg?avatarHeight=100"></a>

### Bronze Sponsors

Support this project by [becoming a Bronze Sponsor](https://opencollective.com//contribute/bronze-sponsor-40966/). The company avatar will show up here with a link to your OpenCollective Profile.

<a href="https://opencollective.com//contribute/bronze-sponsor-40966/checkout"><img src="https://opencollective.com//tiers/bronze-sponsor/0/avatar.svg?avatarHeight=100"></a> 

### Backers

Thanks to all the backers and sponsors! Support this project by [becoming a backer](https://opencollective.com//contribute/backer-40965/).

<a href="https://opencollective.com//contribute/backer-40965/checkout" target="_blank" rel="noopener"><img src="https://opencollective.com//backers.svg?width=890"></a>

<!--- EndOpenCollectiveBackers -->

## Copyright and License

copyright 2023 creativeLabs Łukasz Holeczek.   

 
Code released under [the MIT license](https://github.com//-free-react-admin-template/blob/master/LICENSE).
There is only one limitation you can't can’t re-distribute the  as stock. You can’t do this if you modify the . In past we faced some problems with persons who tried to sell  based templates.

