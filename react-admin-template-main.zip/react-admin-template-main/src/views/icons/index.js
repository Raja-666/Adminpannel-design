import Icons from './-icons'
import Flags from './flags'
import Brands from './brands'

export { Icons, Flags, Brands }
