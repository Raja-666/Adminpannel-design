import React from 'react'
import { CCard, CCardBody, CCardHeader, CRow } from '@/react'
import { freeSet } from '@/icons'
import { getIconsView } from '../brands/Brands.js'
import { DocsCallout } from 'src/components'

const Icons = () => {
  return (
    <>
      <DocsCallout
        name=" Icons"
        href="components/chart"
        content=" Icons.  Icons package is delivered with more than 1500 icons in multiple formats SVG, PNG, and Webfonts.  Icons are beautifully crafted symbols for common actions and items. You can use them in your digital products for web or mobile app."
      />
      <CCard className="mb-4">
        <CCardHeader>Free Icons</CCardHeader>
        <CCardBody>
          <CRow className="text-center">{getIconsView(freeSet)}</CRow>
        </CCardBody>
      </CCard>
    </>
  )
}

export default Icons
